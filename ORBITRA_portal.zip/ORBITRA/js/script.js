
const menu = document.querySelector(".menu");
const links = document.querySelector(".nav-links");
if(menu) menu.addEventListener("click",()=>links.classList.toggle("open"));

const temp = document.querySelector("#temperature");
const battery = document.querySelector("#battery");
const voltage = document.querySelector("#voltage");
const signal = document.querySelector("#signal");

if(temp && battery && voltage && signal){
  setInterval(()=>{
    temp.textContent = (27 + Math.random()*2.5).toFixed(1) + " °C";
    battery.textContent = Math.max(70, parseInt(battery.textContent)-0.1).toFixed(0) + "%";
    voltage.textContent = (7.6 + Math.random()*.5).toFixed(2) + " V";
    signal.textContent = "-" + Math.floor(58 + Math.random()*10) + " dBm";
  },2500);
}
